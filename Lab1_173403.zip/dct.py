import cv2
import numpy as np

if __name__ == "__main__":

    img = cv2.imread('Lenna_512x512.jpeg', 0) #read image in grayscale
    imf = np.float32(img)  # float conversion/scale

    # Compute dct encoding and store result
    output = cv2.dct(imf)  # the dct
    cv2.imwrite('Lenna_DCT.jpeg', output)

    # Compute inverse dct decoding and store result
    inversa = cv2.idct(output)
    cv2.imwrite('Lenna_iDCT.jpeg', inversa)

