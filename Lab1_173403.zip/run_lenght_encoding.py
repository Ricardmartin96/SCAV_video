def rl_encode(input):
    encoded_input = " " # declare a void string
    i = 0
    while (i < len(input)):
        count = 1
        j = i
        while (j < len(input)-1): # here we check the frequency of each value
            if (input[j] == input[j + 1]):
                count = count + 1
                j = j + 1
            else:
                break
        # here we append the times that each value appears and the value itself
        encoded_input = encoded_input + input[i] + str(count)  # all variables must be the same type (strings)
        i = j + 1
    return encoded_input

if __name__ == "__main__":
    input= input("Introduce a string: ")
    print ('output: ', rl_encode(input))