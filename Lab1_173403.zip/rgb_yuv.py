import sys

if __name__ == '__main__':

    R = int(input("Please enter an R value: "))
    if (R<0)or(R>255):
        print("wrong value, try again")
        sys.exit()

    G = int(input("Please enter an G value: "))
    if (G<0)or(G>255):
        print("wrong value, try again")
        sys.exit()

    B = int(input("Please enter an B value: "))
    if (B < 0)or(B > 255):
        print("wrong value, try again")
        sys.exit()

    Y = 0.257*R + 0.504*G + 0.098*B + 16;
    U = -0.148*R - 0.291*G + 0.439*B + 128;
    V = 0.439*R - 0.368*G - 0.071*B + 128;

    Rb = 1.164*(Y-16) + 2.018*(U-128)
    Gb = 1.164*(Y-16) - 0.813*(V-128) - 0.391*(U-128)
    Bb = 1.164*(Y-16) + 1.596*(V-128)

    YUV = [Y, U , V];
    print('YUV', YUV);

    RGB_back = [Rb, Gb, Bb];
    print('Back to RGB', RGB_back);

